﻿namespace hw03_AlexanderThebolt
{
    partial class Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_a_color = new System.Windows.Forms.TextBox();
            this.tb_a_year = new System.Windows.Forms.TextBox();
            this.tb_a_model = new System.Windows.Forms.TextBox();
            this.tb_a_make = new System.Windows.Forms.TextBox();
            this.tb_a_vin = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_a_back = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_a_add = new System.Windows.Forms.Button();
            this.lbl_a_error = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tb_a_color
            // 
            this.tb_a_color.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_a_color.Location = new System.Drawing.Point(81, 171);
            this.tb_a_color.Name = "tb_a_color";
            this.tb_a_color.Size = new System.Drawing.Size(152, 29);
            this.tb_a_color.TabIndex = 20;
            // 
            // tb_a_year
            // 
            this.tb_a_year.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_a_year.Location = new System.Drawing.Point(81, 142);
            this.tb_a_year.Name = "tb_a_year";
            this.tb_a_year.Size = new System.Drawing.Size(152, 29);
            this.tb_a_year.TabIndex = 19;
            // 
            // tb_a_model
            // 
            this.tb_a_model.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_a_model.Location = new System.Drawing.Point(81, 113);
            this.tb_a_model.Name = "tb_a_model";
            this.tb_a_model.Size = new System.Drawing.Size(152, 29);
            this.tb_a_model.TabIndex = 18;
            // 
            // tb_a_make
            // 
            this.tb_a_make.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_a_make.Location = new System.Drawing.Point(81, 84);
            this.tb_a_make.Name = "tb_a_make";
            this.tb_a_make.Size = new System.Drawing.Size(152, 29);
            this.tb_a_make.TabIndex = 17;
            // 
            // tb_a_vin
            // 
            this.tb_a_vin.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_a_vin.Location = new System.Drawing.Point(81, 55);
            this.tb_a_vin.Name = "tb_a_vin";
            this.tb_a_vin.Size = new System.Drawing.Size(152, 29);
            this.tb_a_vin.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 24);
            this.label5.TabIndex = 15;
            this.label5.Text = "Color: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 24);
            this.label4.TabIndex = 14;
            this.label4.Text = "Year: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 24);
            this.label3.TabIndex = 13;
            this.label3.Text = "Model: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 24);
            this.label2.TabIndex = 12;
            this.label2.Text = "Make: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 24);
            this.label1.TabIndex = 11;
            this.label1.Text = "VIN: ";
            // 
            // btn_a_back
            // 
            this.btn_a_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_a_back.Location = new System.Drawing.Point(17, 206);
            this.btn_a_back.Name = "btn_a_back";
            this.btn_a_back.Size = new System.Drawing.Size(75, 37);
            this.btn_a_back.TabIndex = 21;
            this.btn_a_back.Text = "Back";
            this.btn_a_back.UseVisualStyleBackColor = true;
            this.btn_a_back.Click += new System.EventHandler(this.btn_a_back_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(76, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 25);
            this.label6.TabIndex = 22;
            this.label6.Text = "Add Car";
            // 
            // btn_a_add
            // 
            this.btn_a_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_a_add.Location = new System.Drawing.Point(158, 206);
            this.btn_a_add.Name = "btn_a_add";
            this.btn_a_add.Size = new System.Drawing.Size(75, 37);
            this.btn_a_add.TabIndex = 23;
            this.btn_a_add.Text = "Add";
            this.btn_a_add.UseVisualStyleBackColor = true;
            this.btn_a_add.Click += new System.EventHandler(this.btn_a_add_Click);
            // 
            // lbl_a_error
            // 
            this.lbl_a_error.AutoSize = true;
            this.lbl_a_error.ForeColor = System.Drawing.Color.Red;
            this.lbl_a_error.Location = new System.Drawing.Point(86, 39);
            this.lbl_a_error.Name = "lbl_a_error";
            this.lbl_a_error.Size = new System.Drawing.Size(143, 13);
            this.lbl_a_error.TabIndex = 24;
            this.lbl_a_error.Text = "ERROR: Please Fill All Fields";
            this.lbl_a_error.Visible = false;
            // 
            // Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(245, 255);
            this.Controls.Add(this.lbl_a_error);
            this.Controls.Add(this.btn_a_add);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btn_a_back);
            this.Controls.Add(this.tb_a_color);
            this.Controls.Add(this.tb_a_year);
            this.Controls.Add(this.tb_a_model);
            this.Controls.Add(this.tb_a_make);
            this.Controls.Add(this.tb_a_vin);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Add";
            this.Text = "Add";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_a_color;
        private System.Windows.Forms.TextBox tb_a_year;
        private System.Windows.Forms.TextBox tb_a_model;
        private System.Windows.Forms.TextBox tb_a_make;
        private System.Windows.Forms.TextBox tb_a_vin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_a_back;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_a_add;
        private System.Windows.Forms.Label lbl_a_error;
    }
}