﻿namespace hw03_AlexanderThebolt
{
    partial class Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_d_carDetails = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_d_vin = new System.Windows.Forms.TextBox();
            this.tb_d_make = new System.Windows.Forms.TextBox();
            this.tb_d_model = new System.Windows.Forms.TextBox();
            this.tb_d_year = new System.Windows.Forms.TextBox();
            this.tb_d_color = new System.Windows.Forms.TextBox();
            this.btn_d_update = new System.Windows.Forms.Button();
            this.btn_d_delete = new System.Windows.Forms.Button();
            this.lbl_d_error = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_d_carDetails
            // 
            this.lbl_d_carDetails.AutoSize = true;
            this.lbl_d_carDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_d_carDetails.Location = new System.Drawing.Point(63, 13);
            this.lbl_d_carDetails.Name = "lbl_d_carDetails";
            this.lbl_d_carDetails.Size = new System.Drawing.Size(118, 25);
            this.lbl_d_carDetails.TabIndex = 0;
            this.lbl_d_carDetails.Text = "Car Details";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "VIN: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Make: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Model: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "Year: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "Color: ";
            // 
            // tb_d_vin
            // 
            this.tb_d_vin.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_d_vin.Location = new System.Drawing.Point(81, 55);
            this.tb_d_vin.Name = "tb_d_vin";
            this.tb_d_vin.Size = new System.Drawing.Size(152, 29);
            this.tb_d_vin.TabIndex = 6;
            // 
            // tb_d_make
            // 
            this.tb_d_make.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_d_make.Location = new System.Drawing.Point(81, 84);
            this.tb_d_make.Name = "tb_d_make";
            this.tb_d_make.Size = new System.Drawing.Size(152, 29);
            this.tb_d_make.TabIndex = 7;
            // 
            // tb_d_model
            // 
            this.tb_d_model.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_d_model.Location = new System.Drawing.Point(81, 113);
            this.tb_d_model.Name = "tb_d_model";
            this.tb_d_model.Size = new System.Drawing.Size(152, 29);
            this.tb_d_model.TabIndex = 8;
            // 
            // tb_d_year
            // 
            this.tb_d_year.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_d_year.Location = new System.Drawing.Point(81, 142);
            this.tb_d_year.Name = "tb_d_year";
            this.tb_d_year.Size = new System.Drawing.Size(152, 29);
            this.tb_d_year.TabIndex = 9;
            // 
            // tb_d_color
            // 
            this.tb_d_color.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_d_color.Location = new System.Drawing.Point(81, 171);
            this.tb_d_color.Name = "tb_d_color";
            this.tb_d_color.Size = new System.Drawing.Size(152, 29);
            this.tb_d_color.TabIndex = 10;
            // 
            // btn_d_update
            // 
            this.btn_d_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_d_update.Location = new System.Drawing.Point(149, 206);
            this.btn_d_update.Name = "btn_d_update";
            this.btn_d_update.Size = new System.Drawing.Size(84, 37);
            this.btn_d_update.TabIndex = 11;
            this.btn_d_update.Text = "Update";
            this.btn_d_update.UseVisualStyleBackColor = true;
            this.btn_d_update.Click += new System.EventHandler(this.btn_d_update_Click);
            // 
            // btn_d_delete
            // 
            this.btn_d_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_d_delete.Location = new System.Drawing.Point(12, 206);
            this.btn_d_delete.Name = "btn_d_delete";
            this.btn_d_delete.Size = new System.Drawing.Size(84, 37);
            this.btn_d_delete.TabIndex = 12;
            this.btn_d_delete.Text = "Delete";
            this.btn_d_delete.UseVisualStyleBackColor = true;
            this.btn_d_delete.Click += new System.EventHandler(this.btn_d_delete_Click);
            // 
            // lbl_d_error
            // 
            this.lbl_d_error.AutoSize = true;
            this.lbl_d_error.ForeColor = System.Drawing.Color.Red;
            this.lbl_d_error.Location = new System.Drawing.Point(86, 38);
            this.lbl_d_error.Name = "lbl_d_error";
            this.lbl_d_error.Size = new System.Drawing.Size(143, 13);
            this.lbl_d_error.TabIndex = 25;
            this.lbl_d_error.Text = "ERROR: Please Fill All Fields";
            this.lbl_d_error.Visible = false;
            // 
            // Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(245, 255);
            this.Controls.Add(this.lbl_d_error);
            this.Controls.Add(this.btn_d_delete);
            this.Controls.Add(this.btn_d_update);
            this.Controls.Add(this.tb_d_color);
            this.Controls.Add(this.tb_d_year);
            this.Controls.Add(this.tb_d_model);
            this.Controls.Add(this.tb_d_make);
            this.Controls.Add(this.tb_d_vin);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_d_carDetails);
            this.Name = "Details";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_d_carDetails;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_d_vin;
        private System.Windows.Forms.TextBox tb_d_make;
        private System.Windows.Forms.TextBox tb_d_model;
        private System.Windows.Forms.TextBox tb_d_year;
        private System.Windows.Forms.TextBox tb_d_color;
        private System.Windows.Forms.Button btn_d_update;
        private System.Windows.Forms.Button btn_d_delete;
        private System.Windows.Forms.Label lbl_d_error;
    }
}